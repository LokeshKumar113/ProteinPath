# 🥩 ProteinPath

**A smart, location-aware food recommendation app that helps you hit your daily protein goals by finding the most efficient meals (protein per dollar) from nearby restaurants.**

![ProteinPath](https://img.shields.io/badge/React-18-blue) ![Vite](https://img.shields.io/badge/Vite-5-purple) ![License](https://img.shields.io/badge/license-MIT-green)

---

## Features

- **Daily dashboard** — protein progress ring, remaining target, budget left, and today's meals at a glance
- **Restaurant discovery** — nearby options ranked by protein efficiency (g per $), with badges for top picks
- **Smart filtering** — sort by best value or closest distance; meals over budget are automatically marked
- **One-tap meal logging** — log any meal directly from the discovery screen
- **Meal log** — view, track, and remove logged meals throughout the day
- **User profile** — set your name, protein goal, daily budget, dietary preference, and location
- **Persistent storage** — meals and profile saved to localStorage, survives page refresh
- **Dark mode** — fully adapts to system preference

---

## Tech Stack

| Layer | Tech |
|-------|------|
| Framework | React 18 |
| Build tool | Vite 5 |
| Icons | Lucide React |
| Fonts | DM Sans (Google Fonts) |
| Storage | localStorage |
| Styling | Plain CSS with CSS custom properties |

---

## Getting Started

### Prerequisites
- Node.js 18+
- npm 9+

### Installation

```bash
git clone https://github.com/YOUR_USERNAME/proteinpath.git
cd proteinpath
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Build for production

```bash
npm run build
npm run preview
```

---

## Project Structure

```
proteinpath/
├── src/
│   ├── data/
│   │   └── restaurants.js      # Sample restaurant & meal data
│   ├── hooks/
│   │   └── useStorage.js       # Meal log + profile state (localStorage)
│   ├── pages/
│   │   ├── Dashboard.jsx       # Progress ring, stats, today's meals
│   │   ├── Discover.jsx        # Restaurant discovery + meal logging
│   │   ├── MealLog.jsx         # Full log view
│   │   └── Profile.jsx         # User settings
│   ├── App.jsx                 # Root component + navigation
│   ├── App.css                 # Global styles
│   └── main.jsx                # Entry point
├── index.html
├── vite.config.js
└── package.json
```

---

## Roadmap / Future Ideas

- [ ] Real location data via Google Places API or Yelp Fusion
- [ ] Actual restaurant menus via nutrition APIs (Nutritionix, USDA)
- [ ] Weekly/monthly protein trend charts
- [ ] Push notifications for meal reminders
- [ ] Sharing / social features
- [ ] Native mobile app (React Native)
- [ ] Backend + user accounts for multi-device sync

---

## Contributing

Pull requests welcome! Please open an issue first to discuss what you'd like to change.

---

## License

MIT
